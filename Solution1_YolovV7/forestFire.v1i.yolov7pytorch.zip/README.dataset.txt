# forestFire > 2025-01-13 2:38pm
https://universe.roboflow.com/education-f32oy/forestfire-1x0i0

Provided by a Roboflow user
License: CC BY 4.0

